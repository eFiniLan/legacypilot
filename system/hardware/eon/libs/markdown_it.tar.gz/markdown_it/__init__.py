"""A Python port of Markdown-It"""
__all__ = ("MarkdownIt",)
__version__ = "2.1.0"

from .main import MarkdownIt
